--
-- PostgreSQL database dump
--

\restrict 9rY06ZUPfVxe8YqL9PV0OejLcRT7rRdkdg91hWJUmc6t9S8ADGEAd7pLS9RuyOE

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bids (
    id integer NOT NULL,
    request_id integer NOT NULL,
    supplier_name text NOT NULL,
    supplier_store text NOT NULL,
    supplier_email text NOT NULL,
    price numeric(10,2) NOT NULL,
    offer_type text NOT NULL,
    model_name text NOT NULL,
    description text NOT NULL,
    warranty_months integer DEFAULT 12 NOT NULL,
    delivery_days integer DEFAULT 3 NOT NULL,
    image_url text,
    is_similar_model boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bids_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bids_id_seq OWNED BY public.bids.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    icon text NOT NULL,
    description text NOT NULL,
    fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connections (
    id integer NOT NULL,
    supplier_id integer,
    request_id integer NOT NULL,
    bid_id integer NOT NULL,
    consumer_name text NOT NULL,
    consumer_email text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: connections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.connections_id_seq OWNED BY public.connections.id;


--
-- Name: credit_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_purchases (
    id integer NOT NULL,
    supplier_id integer,
    bundle_name text NOT NULL,
    credits_amount integer NOT NULL,
    amount_paid_cents integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_purchases_id_seq OWNED BY public.credit_purchases.id;


--
-- Name: requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.requests (
    id integer NOT NULL,
    title text NOT NULL,
    brand text NOT NULL,
    description text NOT NULL,
    category_id integer NOT NULL,
    specifications jsonb DEFAULT '{}'::jsonb NOT NULL,
    allowed_offer_types jsonb DEFAULT '["new"]'::jsonb NOT NULL,
    allow_similar_models boolean DEFAULT false NOT NULL,
    consumer_name text NOT NULL,
    consumer_email text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.requests_id_seq OWNED BY public.requests.id;


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id integer NOT NULL,
    offline_mode boolean DEFAULT false NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: supplier_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_accounts (
    id integer NOT NULL,
    store_name text NOT NULL,
    contact_name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    credits integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: supplier_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplier_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplier_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplier_accounts_id_seq OWNED BY public.supplier_accounts.id;


--
-- Name: user_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_accounts (
    id integer NOT NULL,
    role text NOT NULL,
    store_name text,
    contact_name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    credits integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    email_verification_token text,
    password_reset_token text,
    password_reset_expires timestamp without time zone,
    username text,
    CONSTRAINT user_accounts_role_check CHECK ((role = ANY (ARRAY['buyer'::text, 'seller'::text])))
);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_accounts_id_seq OWNED BY public.user_accounts.id;


--
-- Name: bids id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bids ALTER COLUMN id SET DEFAULT nextval('public.bids_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: connections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections ALTER COLUMN id SET DEFAULT nextval('public.connections_id_seq'::regclass);


--
-- Name: credit_purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases ALTER COLUMN id SET DEFAULT nextval('public.credit_purchases_id_seq'::regclass);


--
-- Name: requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests ALTER COLUMN id SET DEFAULT nextval('public.requests_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: supplier_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_accounts ALTER COLUMN id SET DEFAULT nextval('public.supplier_accounts_id_seq'::regclass);


--
-- Name: user_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts ALTER COLUMN id SET DEFAULT nextval('public.user_accounts_id_seq'::regclass);


--
-- Data for Name: bids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bids (id, request_id, supplier_name, supplier_store, supplier_email, price, offer_type, model_name, description, warranty_months, delivery_days, image_url, is_similar_model, created_at) FROM stdin;
1	1	Peter Bakker	MediaMarkt Amsterdam	peter@mediamarkt.nl	1299.00	new	Samsung QE65S95C OLED	Splinternieuwe Samsung OLED 65 inch met garantie. Direct uit voorraad leverbaar.	24	2	\N	f	2026-03-26 06:32:32.789758
2	1	Lisa van Dam	CoolBlue Den Haag	lisa@coolblue.nl	1189.00	new	Samsung QE65S95CATXXN	Nieuwe Samsung OLED met gratis installatie en wegbrengen van je oude TV.	24	3	\N	f	2026-03-26 06:32:32.789758
3	1	Mark Hendriks	TV Outlet Rotterdam	mark@tvoutlet.nl	899.00	refurbished	Samsung QE65S95B OLED	Refurbished vorig jaar model, in uitstekende staat met 12 maanden garantie.	12	5	\N	t	2026-03-26 06:32:32.789758
4	2	Tom van der Berg	Apple Premium Reseller Utrecht	tom@applereseller.nl	2149.00	new	Apple MacBook Pro 14" M3 Pro 18GB/512GB	Nieuw in doos, inclusief Apple Care+ aanbieding. Vandaag besteld, morgen in huis.	12	1	\N	f	2026-03-26 06:32:32.797834
5	2	Emma de Jong	BCC Eindhoven	emma@bcc.nl	2099.00	new	Apple MacBook Pro 14" M3 16GB/512GB	Nieuw exemplaar, incl. 2 jaar garantie via Apple. Gratis levering.	24	2	\N	f	2026-03-26 06:32:32.797834
6	3	Alex van Houten	AutoCenter De Lely	alex@autocenterlely.nl	22500.00	occasion	Volkswagen Golf 1.5 TSI Life 2021	Golf uit 2021, 45.000 km, volledig dealer onderhouden. Inclusief navigatie en achteruitrijcamera.	12	7	\N	f	2026-03-26 06:32:32.803665
7	3	Karin Mulder	Auto Palace Amsterdam	karin@autopalace.nl	24900.00	occasion	Volkswagen Golf 2.0 TDI Style 2022	Diesel Golf 2022 met alleen 30.000km. Panoramadak, leer, full opties.	24	5	\N	f	2026-03-26 06:32:32.803665
8	3	Dave Willemsen	Seat & VW Specialist Breda	dave@seatvw.nl	19990.00	occasion	SEAT Leon 1.5 TSI FR 2021	Soortgelijk model, SEAT Leon is op hetzelfde platform gebouwd als Golf. Iets sportiever, zelfde betrouwbaarheid.	12	3	\N	t	2026-03-26 06:32:32.803665
9	4	Bas Hoekstra	GSM Planet	bas@gsmplanet.nl	1249.00	new	Samsung Galaxy S24 Ultra 256GB Titanium Black	Nieuw, ongeopend in doos. Inclusief Samsung headset cadeau.	24	1	\N	f	2026-03-26 06:32:32.809585
10	4	Noor van Leeuwen	Belsimpel	noor@belsimpel.nl	1199.00	new	Samsung Galaxy S24 Ultra 256GB	Nieuw toestel met 24 maanden fabrieksgarantie. Morgen geleverd bij bestelling voor 23:00.	24	1	\N	f	2026-03-26 06:32:32.809585
11	6	freek	Koele freek	vriesmans@xs4all.nl	599.00	new	EC1000	koop bij mij want ik ben beter	24	1	\N	f	2026-03-26 06:48:54.708682
12	1	Test Winkel	MediaMarkt	test@test.nl	999.00	new	Samsung QE55S90C		24	2	\N	f	2026-03-26 06:51:33.950769
13	6	Bert	Bertus	vriesmans@xs4all.nl	560.00	new	EC1000		36	4	\N	f	2026-03-26 06:53:55.643932
14	7	karel	karel	karel@karel.com	25.00	new	KL99981		36	1	\N	f	2026-03-26 06:57:34.440948
15	2	piet	winkel1	vriesmans@xs4all.nl	2000.00	new	test		24	1	\N	f	2026-03-26 18:44:08.055713
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, slug, icon, description, fields, created_at, updated_at, is_active) FROM stdin;
1	Televisie	televisie	📺	Smart TV's, OLED, QLED en meer	[{"key": "screenSize", "type": "select", "label": "Schermgrootte (inch)", "options": ["32", "43", "50", "55", "65", "75", "85"], "required": true}, {"key": "resolution", "type": "select", "label": "Resolutie", "options": ["HD (1280x720)", "Full HD (1920x1080)", "4K Ultra HD", "8K"], "required": true}, {"key": "displayType", "type": "select", "label": "Schermtype", "options": ["LED", "OLED", "QLED", "MiniLED", "AMOLED"], "required": false}, {"key": "smart", "type": "boolean", "label": "Smart TV", "required": true}, {"key": "hdr", "type": "select", "label": "HDR", "options": ["Geen", "HDR10", "HDR10+", "Dolby Vision"], "required": false}, {"key": "refreshRate", "type": "select", "label": "Verversingssnelheid (Hz)", "options": ["50", "60", "100", "120", "144"], "required": false}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. gaming functies, specifieke apps..."}]	2026-03-26 06:32:32.711499	2026-03-26 06:32:32.711499	t
2	Wasmachine	wasmachine	🫧	Wasmachines, drogers en wasdrogers	[{"key": "type", "type": "select", "label": "Type", "options": ["Wasmachine", "Droger", "Wasdroger"], "required": true}, {"key": "capacity", "type": "select", "label": "Capaciteit (kg)", "options": ["5", "6", "7", "8", "9", "10", "11", "12"], "required": true}, {"key": "energyLabel", "type": "select", "label": "Energielabel (minimaal)", "options": ["A", "B", "C", "D", "E"], "required": false}, {"key": "spinSpeed", "type": "select", "label": "Toerental (max rpm)", "options": ["800", "1000", "1200", "1400", "1600"], "required": false}, {"key": "placement", "type": "select", "label": "Plaatsing", "options": ["Vrijstaand", "Inbouw", "Maakt niet uit"], "required": true}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. stoomfunctie, allergikerprogramma..."}]	2026-03-26 06:32:32.745595	2026-03-26 06:32:32.745595	t
3	Laptop	laptop	💻	Laptops voor werk, gaming en studie	[{"key": "screenSize", "type": "select", "label": "Schermgrootte (inch)", "options": ["13", "14", "15", "16", "17"], "required": true}, {"key": "processor", "type": "select", "label": "Processor", "options": ["Intel Core i3", "Intel Core i5", "Intel Core i7", "Intel Core i9", "AMD Ryzen 5", "AMD Ryzen 7", "AMD Ryzen 9", "Apple M1", "Apple M2", "Apple M3"], "required": true}, {"key": "ram", "type": "select", "label": "RAM (GB)", "options": ["4", "8", "16", "32", "64"], "required": true}, {"key": "storage", "type": "select", "label": "Opslag", "options": ["128GB SSD", "256GB SSD", "512GB SSD", "1TB SSD", "2TB SSD", "1TB HDD"], "required": true}, {"key": "usage", "type": "select", "label": "Gebruik", "options": ["Thuisgebruik", "Zakelijk", "Gaming", "Design/Video", "Studie"], "required": true}, {"key": "os", "type": "select", "label": "Besturingssysteem", "options": ["Windows 11", "macOS", "Linux", "Maakt niet uit"], "required": false}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. touchscreen, goede batterijduur..."}]	2026-03-26 06:32:32.751689	2026-03-26 06:32:32.751689	t
4	Smartphone	smartphone	📱	Smartphones van alle merken	[{"key": "os", "type": "select", "label": "Besturingssysteem", "options": ["Android", "iOS", "Maakt niet uit"], "required": true}, {"key": "storage", "type": "select", "label": "Opslag (GB)", "options": ["64", "128", "256", "512", "1024"], "required": true}, {"key": "ram", "type": "select", "label": "RAM (GB)", "options": ["4", "6", "8", "12", "16"], "required": false}, {"key": "camera", "type": "select", "label": "Camera (minimaal MP)", "options": ["12", "48", "50", "64", "108", "200"], "required": false}, {"key": "battery", "type": "select", "label": "Accu (minimaal mAh)", "options": ["3000", "4000", "5000", "6000"], "required": false}, {"key": "connectivity", "type": "select", "label": "Connectiviteit", "options": ["4G", "5G", "Maakt niet uit"], "required": false}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. waterbestendig, specifieke camera functies..."}]	2026-03-26 06:32:32.756779	2026-03-26 06:32:32.756779	t
5	Auto	auto	🚗	Nieuwe en tweedehands auto's	[{"key": "bodyType", "type": "select", "label": "Carrosserie", "options": ["Hatchback", "Sedan", "SUV", "Stationwagon", "Coupé", "Cabriolet", "MPV/Van", "Pickup"], "required": true}, {"key": "fuel", "type": "select", "label": "Brandstof", "options": ["Benzine", "Diesel", "Elektrisch", "Hybride (plug-in)", "Hybride", "LPG", "Waterstof"], "required": true}, {"key": "transmission", "type": "select", "label": "Transmissie", "options": ["Handgeschakeld", "Automaat", "Semi-automaat", "Maakt niet uit"], "required": true}, {"key": "minYear", "type": "number", "label": "Bouwjaar (minimum)", "required": false, "placeholder": "Bijv. 2018"}, {"key": "maxKm", "type": "number", "label": "Max. kilometerstand", "required": false, "placeholder": "Bijv. 80000"}, {"key": "seats", "type": "select", "label": "Aantal zitplaatsen", "options": ["2", "4", "5", "7", "8+"], "required": false}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. trekhaak, navigatie, specifieke kleur..."}]	2026-03-26 06:32:32.761666	2026-03-26 06:32:32.761666	t
6	Koelkast	koelkast	🧊	Koelkasten, vriezers en koel-vriescombinaties	[{"key": "type", "type": "select", "label": "Type", "options": ["Koelkast", "Vriezer", "Koel-vriescombinatie", "Side-by-side", "French door"], "required": true}, {"key": "capacity", "type": "select", "label": "Inhoud (liter)", "options": ["< 100", "100-200", "200-300", "300-400", "400-500", "> 500"], "required": true}, {"key": "energyLabel", "type": "select", "label": "Energielabel (minimaal)", "options": ["A", "B", "C", "D", "E"], "required": false}, {"key": "placement", "type": "select", "label": "Plaatsing", "options": ["Vrijstaand", "Inbouw", "Maakt niet uit"], "required": true}, {"key": "noFrost", "type": "boolean", "label": "No-frost", "required": false}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. water/ijsdispenser, speciale kleur..."}]	2026-03-26 06:32:32.766343	2026-03-26 06:32:32.766343	t
7	Camera	camera	📷	Digitale camera's, DSLR en systeemcamera's	[{"key": "type", "type": "select", "label": "Type camera", "options": ["Compact", "Bridge", "DSLR", "Systeemcamera (mirrorless)", "Actiecamera", "Instant"], "required": true}, {"key": "megapixels", "type": "select", "label": "Megapixels (minimaal)", "options": ["12", "16", "20", "24", "36", "45", "60"], "required": false}, {"key": "videoRes", "type": "select", "label": "Video resolutie", "options": ["Full HD", "4K", "6K", "8K"], "required": false}, {"key": "usage", "type": "select", "label": "Gebruik", "options": ["Hobby", "Semi-professioneel", "Professioneel", "Vlog/YouTube", "Sport/Actie"], "required": true}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. specifiek lenssysteem, wifi, touchscreen..."}]	2026-03-26 06:32:32.772999	2026-03-26 06:32:32.772999	t
8	Fiets	fiets	🚲	Fietsen, e-bikes en speed pedelecs	[{"key": "type", "type": "select", "label": "Type fiets", "options": ["Stadsfiets", "Racefiets", "Mountainbike", "E-bike", "Speed pedelec", "Vouwfiets", "Bakfiets"], "required": true}, {"key": "electric", "type": "boolean", "label": "Elektrisch", "required": true}, {"key": "frameSize", "type": "select", "label": "Framemaat", "options": ["XS (< 50cm)", "S (50-54cm)", "M (54-58cm)", "L (58-62cm)", "XL (> 62cm)", "Weet ik niet"], "required": false}, {"key": "gears", "type": "select", "label": "Aantal versnellingen", "options": ["Geen (single speed)", "3-7", "8-11", "12+", "Maakt niet uit"], "required": false}, {"key": "gender", "type": "select", "label": "Voor", "options": ["Heer", "Dame", "Unisex"], "required": false}, {"key": "notes", "type": "textarea", "label": "Aanvullende wensen", "required": false, "placeholder": "Bijv. accu range, specifiek merk motor..."}]	2026-03-26 06:32:32.778679	2026-03-26 06:32:32.778679	t
\.


--
-- Data for Name: connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.connections (id, supplier_id, request_id, bid_id, consumer_name, consumer_email, created_at, user_id) FROM stdin;
1	1	1	1	Jan de Vries	jan@example.com	2026-03-26 18:09:11.553367	1
\.


--
-- Data for Name: credit_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_purchases (id, supplier_id, bundle_name, credits_amount, amount_paid_cents, created_at, user_id) FROM stdin;
1	1	Starter	10	3500	2026-03-26 18:09:11.472056	1
2	2	Pro	100	25000	2026-03-26 18:30:19.736149	2
\.


--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.requests (id, title, brand, description, category_id, specifications, allowed_offer_types, allow_similar_models, consumer_name, consumer_email, expires_at, created_at) FROM stdin;
1	Samsung 65 inch 4K OLED TV	Samsung	Op zoek naar een goede Samsung OLED televisie voor de woonkamer. Budget is niet het grootste issue, kwaliteit staat voorop.	1	{"hdr": "Dolby Vision", "notes": "Gaming functies zijn een pré", "smart": true, "resolution": "4K Ultra HD", "screenSize": "65", "displayType": "OLED", "refreshRate": "120"}	["new", "refurbished"]	t	Jan de Vries	jan@example.com	2026-03-31 06:32:32.784	2026-03-26 06:32:32.786199
2	Apple MacBook Pro 14 inch M3	Apple	Zoek een MacBook Pro M3 voor professioneel videosnijwerk en design. Moet snel zijn en lang meegaan op de accu.	3	{"os": "macOS", "ram": "16", "notes": "MagSafe, minimaal 2x USB-C, TouchID", "usage": "Design/Video", "storage": "512GB SSD", "processor": "Apple M3", "screenSize": "14"}	["new"]	f	Sophie Visser	sophie@example.nl	2026-04-01 06:32:32.793	2026-03-26 06:32:32.793806
3	Volkswagen Golf 2020 of nieuwer	Volkswagen	Zoek een betrouwbare Volkswagen Golf, liefst occasion in goede staat. Regelmatig gebruik woon-werkverkeer.	5	{"fuel": "Benzine", "maxKm": "80000", "notes": "Airco, navigatie, liefst metallic kleur", "seats": "5", "minYear": "2020", "bodyType": "Hatchback", "transmission": "Handgeschakeld"}	["occasion", "refurbished"]	t	Rick Smit	rick@example.com	2026-03-30 06:32:32.799	2026-03-26 06:32:32.800225
4	Samsung Galaxy S24 Ultra	Samsung	Op zoek naar de Galaxy S24 Ultra voor professioneel camerawerk. S Pen is een must.	4	{"os": "Android", "ram": "12", "notes": "S Pen, titanium frame", "camera": "200", "battery": "5000", "storage": "256", "connectivity": "5G"}	["new", "refurbished"]	f	Maya Hassan	maya@example.nl	2026-03-28 06:32:32.805	2026-03-26 06:32:32.80619
5	LG 55 inch TV	LG		1	{"screenSize": "55"}	["new"]	f	Test Gebruiker	test@example.nl	2026-04-02 06:38:52.48	2026-03-26 06:38:52.499024
6	Extra koude koelkast	Samsung		6	{"type": "Side-by-side", "capacity": "> 500", "placement": "Vrijstaand", "energyLabel": "A"}	["new"]	f	jantje jansen	jansen884@xs4all.nl	2026-04-02 06:45:30.071	2026-03-26 06:45:30.079922
7	televisie	gfdkdjfgj 333		1	{"hdr": "Dolby Vision", "resolution": "HD (1280x720)", "screenSize": "85", "displayType": "AMOLED", "refreshRate": "144"}	["new", "refurbished"]	f	roald de cheapo	roald.busser@albron.nl	2026-04-02 06:56:46.178	2026-03-26 06:56:46.187025
8	Dikke btw	dikke btw	nee	5	{"fuel": "Waterstof", "maxKm": "1", "notes": "nee", "seats": "8+", "minYear": "1888", "bodyType": "Pickup", "transmission": "Automaat"}	["new"]	f	yara	yara006006@gmail.com	2026-04-02 17:45:26.82	2026-03-26 17:45:26.830303
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, offline_mode, updated_at) FROM stdin;
1	f	2026-03-27 06:01:34.096
\.


--
-- Data for Name: supplier_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_accounts (id, store_name, contact_name, email, password_hash, credits, created_at) FROM stdin;
1	MediaMarkt Amsterdam	Piet Klaassen	piet@mediamarkt.nl	$2b$10$KJ4e6hwDjk8tUnvkJ6OPU.YeUE9bjLlp5N8NqBzBu3mz3wfeKMu1K	9	2026-03-26 18:09:03.424637
2	winkel1	piet	vriesmans@xs4all.nl	$2b$10$pOhMn.2D.7hX0zHykRWIVOFZr9Z.7zQicecsNIivqzJ2vnGPtoOhG	100	2026-03-26 18:30:05.428304
\.


--
-- Data for Name: user_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_accounts (id, role, store_name, contact_name, email, password_hash, credits, created_at, is_admin, email_verified, email_verification_token, password_reset_token, password_reset_expires, username) FROM stdin;
1	seller	MediaMarkt Amsterdam	Piet Klaassen	piet@mediamarkt.nl	$2b$10$KJ4e6hwDjk8tUnvkJ6OPU.YeUE9bjLlp5N8NqBzBu3mz3wfeKMu1K	9	2026-03-26 18:09:03.424637	f	f	\N	\N	\N	\N
2	seller	winkel1	piet	vriesmans@xs4all.nl	$2b$10$pOhMn.2D.7hX0zHykRWIVOFZr9Z.7zQicecsNIivqzJ2vnGPtoOhG	100	2026-03-26 18:30:05.428304	f	f	\N	\N	\N	\N
3	seller	Test Winkel	Jan de Vries	jan@testwinkel.nl	$2b$10$LBc656thhJ/OOAjVV7a/ZOevtSi47jgTVPntdMk19wIaEkzDTfq0O	0	2026-03-27 03:52:12.178344	f	f	\N	\N	\N	\N
36	seller	jantje	j	dsdds@sssk.com	$2b$10$baS3KVBYoDJ0tRwqU/coB.swgaJGHXtj6/eJTZeXiRwtes.MKxFfG	0	2026-03-27 04:24:57.380252	f	f	\N	\N	\N	\N
37	buyer	\N	Beheerder	admin@prijsmij.nl	$2b$10$lwUrlbJFhQSiBz9/2MZDQO0puu5.tUQiSHGFm5KGd25mslO.tfrxC	0	2026-03-27 04:37:01.232931	t	t	\N	\N	\N	admin
\.


--
-- Name: bids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bids_id_seq', 15, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 8, true);


--
-- Name: connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.connections_id_seq', 1, true);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_purchases_id_seq', 4, true);


--
-- Name: requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.requests_id_seq', 8, true);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 1, true);


--
-- Name: supplier_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_accounts_id_seq', 2, true);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_accounts_id_seq', 37, true);


--
-- Name: bids bids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (id);


--
-- Name: credit_purchases credit_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_pkey PRIMARY KEY (id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: supplier_accounts supplier_accounts_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_accounts
    ADD CONSTRAINT supplier_accounts_email_unique UNIQUE (email);


--
-- Name: supplier_accounts supplier_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_accounts
    ADD CONSTRAINT supplier_accounts_pkey PRIMARY KEY (id);


--
-- Name: user_accounts user_accounts_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_email_key UNIQUE (email);


--
-- Name: user_accounts user_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_pkey PRIMARY KEY (id);


--
-- Name: user_accounts user_accounts_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_username_key UNIQUE (username);


--
-- Name: bids bids_request_id_requests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_request_id_requests_id_fk FOREIGN KEY (request_id) REFERENCES public.requests(id);


--
-- Name: connections connections_supplier_id_supplier_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_supplier_id_supplier_accounts_id_fk FOREIGN KEY (supplier_id) REFERENCES public.supplier_accounts(id);


--
-- Name: connections connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: credit_purchases credit_purchases_supplier_id_supplier_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_supplier_id_supplier_accounts_id_fk FOREIGN KEY (supplier_id) REFERENCES public.supplier_accounts(id);


--
-- Name: credit_purchases credit_purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: requests requests_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 9rY06ZUPfVxe8YqL9PV0OejLcRT7rRdkdg91hWJUmc6t9S8ADGEAd7pLS9RuyOE

